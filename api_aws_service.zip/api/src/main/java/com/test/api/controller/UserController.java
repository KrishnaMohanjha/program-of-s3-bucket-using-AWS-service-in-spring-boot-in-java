package com.test.api.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.test.api.entity.User;
import com.test.api.service.UserService;
import com.test.api.vo.UserVo;

@RequestMapping("/user")
@RestController
public class UserController {

	@Autowired
	private UserService userService;
	
	
	@PostMapping(value="/register")
    public ResponseEntity<User> registerUser(@RequestParam("photo") MultipartFile photo ,@RequestPart("requiredInfo") UserVo userVo ) throws IOException {
        User user = userService.registerUser(userVo, photo);
        return ResponseEntity.ok(user);
    }
	
	@GetMapping("/get")
    public String getAll() {
        return "krishna mohan jha";
    }
}
