package com.test.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.test.api.entity.Attendance;

public interface AttendanceRepository extends JpaRepository<Attendance,Long> {

}
