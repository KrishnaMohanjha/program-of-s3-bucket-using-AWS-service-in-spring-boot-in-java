package com.test.api.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.test.api.entity.User;
import com.test.api.repository.UserRepository;
import com.test.api.vo.UserVo;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private S3Service s3Service;  

    public User registerUser(UserVo userVo, MultipartFile photo) throws IOException {
        // Upload photo to S3
        String photoUrl = s3Service.uploadFile(photo);

        User user = new User();
        //user.setUserId(userVo.getId());        
        user.setName(userVo.getName());   
        user.setPhotoUrl(photoUrl);  
        return userRepository.save(user);
    }

}
